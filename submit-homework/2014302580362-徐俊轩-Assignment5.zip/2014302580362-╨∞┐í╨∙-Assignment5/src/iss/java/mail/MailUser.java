/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package iss.java.mail;

import java.util.StringTokenizer;
import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

/**
 * 用户信息设置
 * @author Pinckney
 */
public class MailUser extends Authenticator{
    private String username;
    private String password;
    //private String mailad;
    
    
    
    /**
     * 初始化用户信息
     * @param username 用户名
     * @param password 密码
     */
    MailUser(String u,String k){
        username=u;
        password=k;
        //mailad=m;
    }
    
    /**
     * 用户认证类
     * @return 认证用户信息
     */
    @Override
    	public PasswordAuthentication getPasswordAuthentication() {
		return new PasswordAuthentication(username, password);
	}

    
}
