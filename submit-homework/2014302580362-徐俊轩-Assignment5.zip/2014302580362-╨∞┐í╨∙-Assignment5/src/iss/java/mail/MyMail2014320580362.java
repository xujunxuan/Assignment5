/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package iss.java.mail;

import com.sun.mail.imap.*;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Address;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author Pinckney
 */
public class MyMail2014320580362 implements IMailService {
    
    /**
     * @定义邮件会话 
     * 进行收发邮件的工作都是基于这个会话的。
     * Session对象利用了java.util.Properties对象获得了邮件服务器、用户名、密码信息和整个应用程序都要使用到的共享信息。
     */

    private Session session;
    /**
     * @定义用户信息 
     * 用户名 密码设置
     * 
    */
    
//    private String username="";
//    private String password="";
//    private String emailad="";
    
//    private final String username="issjava2015";
//    private final String password="javaiss";
//    private final String emailad="issjava2015@foxmail.com";    
    
//    private final String username="pinckney1995";
//    private final String password="pinckney666";
//    private final String emailad="pinckney1995@foxmail.com";      
    
    
//    private final String username="pinckney";
//    private final String password="xjx66601602";
//    private final String emailad="pinckney@pinckney.win";  
    
//    private final String username="pinckney";
//    private final String password="xjx66601602";
//    private final String emailad="pinckney@pinckney.win";

//    private final String username=" ";
//    private final String password=" ";
//    private final String emailad="pinckney@pinckney.win";    
//    
    private final String username="15821021837";
    private final String password="xjx19951030";
    private final String emailad="15821021837@126.com";   

//    private final String username="pinckney1995";
//    private final String password="pinckney666";
//    private final String emailad="pinckney1995@gmail.com";   
    
    private final String emailnickname="Pinckney_Emiya";
    
//    private final String smtphost="smtp.ym.163.com";
//    private final String imaphost="imap.ym.163.com";
//    private final String pop3host="pop3.ym.163.com";
    
    private final String smtphost="smtp.126.com";//smtp.ym.163.com
    private final String imaphost="imap.126.com";//imap.ym.163.com
    private final String pop3host="pop3.126.com";//pop3.ym.163.com
    
//    private final String smtphost="smtp.exmail.qq.com";//smtp.ym.163.com
//    private final String imaphost="imap.exmail.qq.com";//imap.ym.163.com
//    private final String pop3host="pop.exmail.qq.com";//pop3.ym.163.com    

//    private final String smtphost="smtp.gmail.com";//smtp.ym.163.com
//    private final String imaphost="imap.gmail.com";//imap.ym.163.com
//    private final String pop3host="pop3.gmail.com";//pop3.ym.163.com
    
    @Override
    
    public void connect() throws MessagingException {
        //配置邮箱协议
        Properties prop=new Properties();
        prop.setProperty("mail.transport.procotol", "smtp");
        prop.setProperty("mail.store.procotol", "imap");

        prop.setProperty("mail.smtp.host",smtphost);
        prop.setProperty("mail.smtp.auth", "true");

        prop.setProperty("mail.imap.host", imaphost );
        prop.setProperty("mail.imap.auth", "true");
        prop.setProperty("mail.imap.user", username);
        prop.setProperty("mail.imap.password", password);

        prop.setProperty("mail.pop3.host", pop3host );
        prop.setProperty("mail.pop3.auth", "true");
        prop.setProperty("mail.pop3.user", username);
        prop.setProperty("mail.pop3.password",  password);        
        
        
        //获取会话实例
        session=Session.getDefaultInstance(prop,new MailUser(username,password));
        //session.setDebug(true); 
    }   

    @Override
    public void send(String recipient, String subject, Object content) throws MessagingException {
        //System.out.println("test");
        
        Message message=new MimeMessage(session);
        try {
            message.setFrom(new InternetAddress(emailad,emailnickname));
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(MyMail2014320580362.class.getName()).log(Level.SEVERE, null, ex);
        }
        message.setRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
        message.setSubject(subject);
        message.setContent(content, "text/html;charset=utf-8");
        
        //message.setText(subject);
        
         Transport.send(message);
         
         
    }

    @Override
    public boolean listen() throws MessagingException {
        Store store=session.getStore("imap");
        store.connect(username,password);

        Folder folder=store.getFolder("INBOX");
        folder.open(Folder.READ_ONLY);
        boolean temp=folder.hasNewMessages();

        folder.close(false);
        store.close();
        return temp;
    }

    @Override
    public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
        IMAPStore store=(IMAPStore) session.getStore("imap");
        store.connect(username,password);
        
        Folder folder=store.getFolder("INBOX");
        folder.open(Folder.READ_ONLY);
        Message message=folder.getMessages()[0];
        Address address=message.getFrom()[0];
        String s=address.toString();
        String temp = null;
        if(s.contains(sender)){
                temp=message.getContent().toString();
        }
        folder.close(false);
        store.close();
        return temp;
//        return null;
    }
    
}
